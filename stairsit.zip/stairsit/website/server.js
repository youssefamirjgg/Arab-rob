const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3001;

// Middleware لتمرير البيانات والملفات المباشرة
app.use(express.json());
app.use(express.static(path.join(__dirname, 'views')));

// ==========================================
// 🗄️ قاعدة بيانات المستخدمين (في الذاكرة)
// ==========================================
const users = {
    'youssef': { username: 'youssef', coins: 1000, role: 'Founder & Admin', verified: true, badge: '👑' }
};

// ==========================================
// 🌐 مسارات الصفحات (Routes)
// ==========================================

// الصفحة الرئيسية
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// صفحة المتجر
app.get('/shop', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'shop.html'));
});

// صفحة محرر السكن
app.get('/avatar-editor', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'avatar-editor.html'));
});

// صفحة تسجيل الدخول
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// صفحة إنشاء حساب
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'register.html'));
});

// 🎯 لعبة شوتر وباركور الباكون العربي 2D
app.get('/game-shooter', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'game-shooter.html'));
});

// ⚽ لعبة كرة القدم العربية 2D
app.get('/game-soccer', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'game-soccer.html'));
});

// ==========================================
// 🔌 APIs للتوثيق والبحث والـ Coins
// ==========================================

// 🔍 API البحث عن المستخدمين والتوثيق بالتاج
app.get('/api/search/users', (req, res) => {
    const query = req.query.q ? req.query.q.toLowerCase().trim() : '';

    const allUsers = [
        { 
            username: 'youssef', 
            displayName: 'Youssef (Owner)', 
            verified: true, 
            badge: '👑', 
            role: 'Founder & Admin',
            avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=youssef'
        },
        { 
            username: 'ahmed', 
            displayName: 'Ahmed 2D', 
            verified: false, 
            badge: '', 
            role: 'Player',
            avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ahmed'
        },
        { 
            username: 'bacon_king', 
            displayName: 'Bacon Pro', 
            verified: false, 
            badge: '', 
            role: 'Player',
            avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=bacon'
        }
    ];

    if (!query) {
        return res.json({ success: true, results: [] });
    }

    const results = allUsers.filter(user => 
        user.username.toLowerCase().includes(query) || 
        user.displayName.toLowerCase().includes(query)
    );

    res.json({ success: true, results });
});

// تسجيل الدخول
app.post('/api/login', (req, res) => {
    const { username } = req.body;
    if (!username) return res.json({ success: false, message: 'ادخل اسم المستخدم' });

    const key = username.toLowerCase();
    if (!users[key]) {
        users[key] = { username, coins: 100, role: 'Player', verified: false, badge: '' };
    }

    res.json({ success: true, message: 'تم تسجيل الدخول بنجاح!', username });
});

// إنشاء حساب
app.post('/api/register', (req, res) => {
    const { username } = req.body;
    if (!username) return res.json({ success: false, message: 'ادخل اسم المستخدم' });

    const key = username.toLowerCase();
    if (users[key]) {
        return res.json({ success: false, message: 'اسم المستخدم موجود بالفعل!' });
    }

    users[key] = { username, coins: 100, role: 'Player', verified: false, badge: '' };
    res.json({ success: true, message: 'تم إنشاء الحساب بنجاح!', username });
});

// جلب بيانات المستخدم
app.get('/api/user/info/:username', (req, res) => {
    const username = req.params.username.toLowerCase();
    const user = users[username];

    if (user) {
        res.json({ success: true, coins: user.coins, username: user.username });
    } else {
        res.json({ success: false, coins: 0 });
    }
});

// ==========================================
// 🎮 منطق الـ Multiplayer 2D (Socket.io)
// ==========================================

let players = {};

io.on('connection', (socket) => {
    console.log(`🟢 لاعب جديد دخل السيرفر: ${socket.id}`);

    players[socket.id] = {
        x: 100,
        y: 300,
        name: 'BaconPlayer'
    };

    socket.emit('currentPlayers', players);

    socket.broadcast.emit('newPlayer', {
        id: socket.id,
        playerData: players[socket.id]
    });

    socket.on('playerMove', (movementData) => {
        if (players[socket.id]) {
            players[socket.id].x = movementData.x;
            players[socket.id].y = movementData.y;
            players[socket.id].name = movementData.name;

            socket.broadcast.emit('playerMoved', {
                id: socket.id,
                playerData: players[socket.id]
            });
        }
    });

    socket.on('disconnect', () => {
        console.log(`🔴 لاعب خرج من السيرفر: ${socket.id}`);
        delete players[socket.id];
        io.emit('playerDisconnected', socket.id);
    });
});

// ==========================================
// 🚀 تشغيل السيرفر
// ==========================================
server.listen(PORT, () => {
    console.log(`
  =========================================
  🚀 ArabRob 2D Server Running!
  🔗 Open: http://localhost:${PORT}
  👑 Searching for "youssef" will display Admin Crown!
  =========================================
    `);
});