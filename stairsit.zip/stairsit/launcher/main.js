const { app, BrowserWindow } = require('electron');
const path = require('path');
const { exec } = require('child_process');

const PROTOCOL = 'arabrob';

// تسجيل بروتوكول التشغيل الخاص بـ ArabRob في نظام التشغيل
if (process.defaultApp) {
  if (process.argv.length >= 2) {
    app.setAsDefaultProtocolClient(PROTOCOL, process.execPath, [path.resolve(process.argv[1])]);
  }
} else {
  app.setAsDefaultProtocolClient(PROTOCOL);
}

// الكود اللي بيتنفذ أول ما اللاعب يضغط "لعب" في الموقع
app.on('open-url', (event, url) => {
  event.preventDefault();
  
  console.log("جاري التحقق وتجهيز اللعبة من الرابط: " + url);
  
  // مسار ملف تشغيل اللعبة (الـ .exe اللي هيتم برمجته بالـ Engine)
  const gamePath = path.join(__dirname, '../game-client/ArabRobGame.exe');
  
  // تشغيل اللعبة وتمرير اسم المستخدم والبيانات لها تلقائياً
  exec(`"${gamePath}" --launcher-url "${url}"`, (error) => {
    if (error) {
        console.error(`فشل تشغيل العميل: ${error}`);
    }
  });
});

app.whenReady().then(() => {
  // نافذة وهمية في الخلفية لانتظار الأوامر من المتصفح
  const win = new BrowserWindow({ width: 0, height: 0, show: false });
});